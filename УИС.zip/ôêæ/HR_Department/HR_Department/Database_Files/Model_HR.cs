using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace HR_Department
{
    public partial class Model_HR : DbContext
    {
        public Model_HR()
            : base("name=Model_HR")
        {
        }

        public virtual DbSet<Employees> Employees { get; set; }
        public virtual DbSet<Orders> Orders { get; set; }
        public virtual DbSet<Positions> Positions { get; set; }
        public virtual DbSet<Subdivisions> Subdivisions { get; set; }
        public virtual DbSet<sysdiagrams> sysdiagrams { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Employees>()
                .Property(e => e.Salary)
                .HasPrecision(15, 2);

            modelBuilder.Entity<Employees>()
                .Property(e => e.Phone_number)
                .IsUnicode(false);

            modelBuilder.Entity<Employees>()
                .Property(e => e.Passport)
                .IsUnicode(false);

            modelBuilder.Entity<Employees>()
                .Property(e => e.INN)
                .IsUnicode(false);

            modelBuilder.Entity<Orders>()
                .Property(e => e.Cost_Rub)
                .HasPrecision(15, 2);
        }
    }
}
