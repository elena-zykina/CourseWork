namespace HR_Department
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Employees
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public Employees()
        {
            Orders = new HashSet<Orders>();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Personnel_number { get; set; }

        [StringLength(50)]
        public string Firstname { get; set; }

        [StringLength(50)]
        public string Secondname { get; set; }

        [StringLength(50)]
        public string Midname { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Bithday { get; set; }

        public decimal? Salary { get; set; }

        [StringLength(25)]
        public string City { get; set; }

        [StringLength(200)]
        public string Address { get; set; }

        [StringLength(20)]
        public string Phone_number { get; set; }

        [StringLength(20)]
        public string Passport { get; set; }

        [StringLength(12)]
        public string INN { get; set; }

        public int? Value_of_Dependents { get; set; }

        public bool? Standart_deduction { get; set; }

        public bool? Availability_car { get; set; }

        public int? Subdivision_code { get; set; }

        public int? Position_code { get; set; }

        [StringLength(1)]
        public string Gender { get; set; }

        public bool? Availability_kids { get; set; }

        public int? Number_of_apartments { get; set; }

        public virtual Positions Positions { get; set; }

        public virtual Subdivisions Subdivisions { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<Orders> Orders { get; set; }
    }
}
