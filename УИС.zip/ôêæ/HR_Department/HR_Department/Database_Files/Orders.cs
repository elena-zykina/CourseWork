namespace HR_Department
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Orders
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Order_code { get; set; }

        [StringLength(50)]
        public string Customer { get; set; }

        [Column(TypeName = "date")]
        public DateTime? Order_date { get; set; }

        [StringLength(200)]
        public string Work_type { get; set; }

        public decimal? Cost_Rub { get; set; }

        public int? Personnel_number { get; set; }

        public virtual Employees Employees { get; set; }
    }
}
