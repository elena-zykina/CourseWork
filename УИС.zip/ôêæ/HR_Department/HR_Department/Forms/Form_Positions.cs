﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Positions : Form
    {

        Model_HR database = new Model_HR();

        public string user_state { get; set; }

        public Form_Positions()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            Positions position = (Positions)positionsBindingSource.Current;
            DialogResult dialogresult = MessageBox.Show("Вы действительно хотите удалить запись " + position.Position_code.ToString(), "Удаление должности",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogresult == DialogResult.Yes)
            {
                database.Positions.Remove(position);

                try
                {
                    database.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                positionsBindingSource.DataSource = database.Positions.ToList();
            }
        }

        private void Form_Positions_Load(object sender, EventArgs e)
        {
            positionsBindingSource.DataSource = database.Positions.ToList();
            if(user_state == "Менеджер по персоналу")
            {
                button_delete.Hide();
                button_add.Hide();
                button_change.Hide();
            }
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Form_Posit_add form_position_add = new Form_Posit_add();

            form_position_add.database = database;

            DialogResult dialogresult = form_position_add.ShowDialog();
            if(dialogresult == DialogResult.OK)
            {
                positionsBindingSource.DataSource = database.Positions.ToList();
            }
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            Form_Posit_change form_Posit_change = new Form_Posit_change();
            Positions position = (Positions)positionsBindingSource.Current;

            form_Posit_change.database = database;
            form_Posit_change.position = position;

            DialogResult dialogresult = form_Posit_change.ShowDialog();
            if(dialogresult == DialogResult.OK)
            {
                positionsBindingSource.DataSource = database.Positions.ToList();
            }
        }
    }
}
