﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Posit_add : Form
    {

        public Model_HR database { get; set; }

        public Form_Posit_add()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if(textbox_pos_code.Text == "" || textbox_pos_name.Text == "" || textbox_pos_percent.Text == "")
            {
                MessageBox.Show("Необходимо ввести все требуемые данные!");
                return;
            }

            int code, percent;
            bool code_changed = int.TryParse(textbox_pos_code.Text, out code);
            bool percent_changed = int.TryParse(textbox_pos_percent.Text, out percent);

            if (!code_changed)
            {
                MessageBox.Show("Неверный формат кода: " + textbox_pos_code.Text);
                return;
            }
            if (!percent_changed)
            {
                MessageBox.Show("Неверный формат процента: " + textbox_pos_percent.Text);
                return;
            }

            Positions position = new Positions();
            position.Position_code = code;
            position.Position_name = textbox_pos_name.Text;
            position.Premial_percent = percent;
            database.Positions.Add(position);
            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form_Posit_add_Load(object sender, EventArgs e)
        {

        }
    }
}
