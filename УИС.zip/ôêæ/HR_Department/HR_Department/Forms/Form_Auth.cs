﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Auth : Form
    {

        public string user_state { get; set; }

        public Form_Auth()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_join_Click(object sender, EventArgs e)
        {
            if(comboBox_user.Text == "")
            {
                MessageBox.Show("Введите пользователя!");
                return;
            }
            user_state = comboBox_user.SelectedItem.ToString();
            DialogResult = DialogResult.OK;
        }
    }
}
