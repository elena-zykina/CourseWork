﻿
namespace HR_Department.Forms
{
    partial class Form_Posit_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label position_codeLabel;
            System.Windows.Forms.Label position_nameLabel;
            System.Windows.Forms.Label premial_percentLabel;
            this.textbox_pos_code = new System.Windows.Forms.TextBox();
            this.positionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textbox_pos_name = new System.Windows.Forms.TextBox();
            this.textbox_pos_percent = new System.Windows.Forms.TextBox();
            this.button_save = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            position_codeLabel = new System.Windows.Forms.Label();
            position_nameLabel = new System.Windows.Forms.Label();
            premial_percentLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.positionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // position_codeLabel
            // 
            position_codeLabel.AutoSize = true;
            position_codeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            position_codeLabel.Location = new System.Drawing.Point(12, 9);
            position_codeLabel.Name = "position_codeLabel";
            position_codeLabel.Size = new System.Drawing.Size(87, 13);
            position_codeLabel.TabIndex = 1;
            position_codeLabel.Text = "Код должности:";
            // 
            // position_nameLabel
            // 
            position_nameLabel.AutoSize = true;
            position_nameLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            position_nameLabel.Location = new System.Drawing.Point(12, 35);
            position_nameLabel.Name = "position_nameLabel";
            position_nameLabel.Size = new System.Drawing.Size(118, 13);
            position_nameLabel.TabIndex = 3;
            position_nameLabel.Text = "Название должности:";
            // 
            // premial_percentLabel
            // 
            premial_percentLabel.AutoSize = true;
            premial_percentLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            premial_percentLabel.Location = new System.Drawing.Point(12, 61);
            premial_percentLabel.Name = "premial_percentLabel";
            premial_percentLabel.Size = new System.Drawing.Size(126, 13);
            premial_percentLabel.TabIndex = 5;
            premial_percentLabel.Text = "Премиальный процент:";
            // 
            // textbox_pos_code
            // 
            this.textbox_pos_code.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.positionsBindingSource, "Position_code", true));
            this.textbox_pos_code.Location = new System.Drawing.Point(144, 6);
            this.textbox_pos_code.Name = "textbox_pos_code";
            this.textbox_pos_code.Size = new System.Drawing.Size(145, 20);
            this.textbox_pos_code.TabIndex = 2;
            // 
            // positionsBindingSource
            // 
            this.positionsBindingSource.DataSource = typeof(HR_Department.Positions);
            // 
            // textbox_pos_name
            // 
            this.textbox_pos_name.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.positionsBindingSource, "Position_name", true));
            this.textbox_pos_name.Location = new System.Drawing.Point(144, 32);
            this.textbox_pos_name.Name = "textbox_pos_name";
            this.textbox_pos_name.Size = new System.Drawing.Size(145, 20);
            this.textbox_pos_name.TabIndex = 4;
            // 
            // textbox_pos_percent
            // 
            this.textbox_pos_percent.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.positionsBindingSource, "Premial_percent", true));
            this.textbox_pos_percent.Location = new System.Drawing.Point(144, 58);
            this.textbox_pos_percent.Name = "textbox_pos_percent";
            this.textbox_pos_percent.Size = new System.Drawing.Size(145, 20);
            this.textbox_pos_percent.TabIndex = 6;
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(12, 84);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(125, 30);
            this.button_save.TabIndex = 7;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(164, 84);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 8;
            this.button_exit.Text = "Назад";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // Form_Posit_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(299, 121);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_save);
            this.Controls.Add(position_codeLabel);
            this.Controls.Add(this.textbox_pos_code);
            this.Controls.Add(position_nameLabel);
            this.Controls.Add(this.textbox_pos_name);
            this.Controls.Add(premial_percentLabel);
            this.Controls.Add(this.textbox_pos_percent);
            this.MaximumSize = new System.Drawing.Size(315, 160);
            this.MinimumSize = new System.Drawing.Size(315, 160);
            this.Name = "Form_Posit_add";
            this.Text = "Добавить должность";
            this.Load += new System.EventHandler(this.Form_Posit_add_Load);
            ((System.ComponentModel.ISupportInitialize)(this.positionsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource positionsBindingSource;
        private System.Windows.Forms.TextBox textbox_pos_code;
        private System.Windows.Forms.TextBox textbox_pos_name;
        private System.Windows.Forms.TextBox textbox_pos_percent;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_exit;
    }
}