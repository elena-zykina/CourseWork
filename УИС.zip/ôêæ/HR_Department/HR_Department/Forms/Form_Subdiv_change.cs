﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Subdiv_change : Form
    {

        public Model_HR database { get; set; }

        public Subdivisions subdiv { get; set; }

        public Form_Subdiv_change()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            int bonus;
            bool bonus_changed = int.TryParse(textbox_subdiv_bonus.Text, out bonus);
            if (!bonus_changed)
            {
                MessageBox.Show("Неверный формат бонуса: " + textbox_subdiv_bonus.Text);
                return;
            }
            subdiv.Subdivision_name = textbox_subdiv_name.Text;
            subdiv.Subdivision_bonus = bonus;
            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form_Subdiv_change_Load(object sender, EventArgs e)
        {
            textbox_subdiv_code.Text = subdiv.Subdivision_code.ToString();
            textbox_subdiv_name.Text = subdiv.Subdivision_name.ToString();
            textbox_subdiv_bonus.Text = subdiv.Subdivision_bonus.ToString();
        }
    }
}
