﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Subdivisions : Form
    {

        Model_HR database = new Model_HR();

        public string user_state { get; set; }

        public Form_Subdivisions()
        {
            InitializeComponent();
        }

        private void Form_Subdivisions_Load(object sender, EventArgs e)
        {
            subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            if (user_state == "Менеджер по персоналу")
            {
                button_delete.Hide();
                button_add.Hide();
                button_change.Hide();
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            Subdivisions subdivision = (Subdivisions)subdivisionsBindingSource.Current;

            DialogResult dialogresult = MessageBox.Show("Вы действительно хотите удалить запись " + subdivision.Subdivision_code.ToString(), 
                "Удаление подразделения", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dialogresult == DialogResult.Yes)
            {
                database.Subdivisions.Remove(subdivision);

                try
                {
                    database.SaveChanges();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            }
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            Form_Subdiv_change form_subdiv_change = new Form_Subdiv_change();
            Subdivisions subdiv = (Subdivisions)subdivisionsBindingSource.Current;

            form_subdiv_change.database = database;
            form_subdiv_change.subdiv = subdiv;

            DialogResult dialogresult = form_subdiv_change.ShowDialog();

            if(dialogresult == DialogResult.OK)
            {
                subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            }
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Form_Subdiv_add form_subdiv_add = new Form_Subdiv_add();

            form_subdiv_add.database = database;

            DialogResult dialogresult = form_subdiv_add.ShowDialog();
            if(dialogresult == DialogResult.OK)
            {
                subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            }
        }
    }
}
