﻿
namespace HR_Department.Forms
{
    partial class Form_Empl_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label availability_carLabel;
            System.Windows.Forms.Label availability_kidsLabel;
            System.Windows.Forms.Label bithdayLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label firstnameLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label iNNLabel;
            System.Windows.Forms.Label midnameLabel;
            System.Windows.Forms.Label number_of_apartmentsLabel;
            System.Windows.Forms.Label passportLabel;
            System.Windows.Forms.Label personnel_numberLabel;
            System.Windows.Forms.Label phone_numberLabel;
            System.Windows.Forms.Label position_codeLabel;
            System.Windows.Forms.Label salaryLabel;
            System.Windows.Forms.Label secondnameLabel;
            System.Windows.Forms.Label standart_deductionLabel;
            System.Windows.Forms.Label subdivision_codeLabel;
            System.Windows.Forms.Label value_of_DependentsLabel;
            this.button_save = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.availability_carCheckBox = new System.Windows.Forms.CheckBox();
            this.availability_kidsCheckBox = new System.Windows.Forms.CheckBox();
            this.bithdayDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.firstnameTextBox = new System.Windows.Forms.TextBox();
            this.genderTextBox = new System.Windows.Forms.TextBox();
            this.midnameTextBox = new System.Windows.Forms.TextBox();
            this.number_of_apartmentsTextBox = new System.Windows.Forms.TextBox();
            this.personnel_numberTextBox = new System.Windows.Forms.TextBox();
            this.position_codeComboBox = new System.Windows.Forms.ComboBox();
            this.positionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.salaryTextBox = new System.Windows.Forms.TextBox();
            this.secondnameTextBox = new System.Windows.Forms.TextBox();
            this.standart_deductionCheckBox = new System.Windows.Forms.CheckBox();
            this.subdivision_codeComboBox = new System.Windows.Forms.ComboBox();
            this.subdivisionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.value_of_DependentsTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.passportTextBox = new System.Windows.Forms.MaskedTextBox();
            this.iNNTextBox = new System.Windows.Forms.MaskedTextBox();
            this.phone_numberTextBox = new System.Windows.Forms.MaskedTextBox();
            addressLabel = new System.Windows.Forms.Label();
            availability_carLabel = new System.Windows.Forms.Label();
            availability_kidsLabel = new System.Windows.Forms.Label();
            bithdayLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            firstnameLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            iNNLabel = new System.Windows.Forms.Label();
            midnameLabel = new System.Windows.Forms.Label();
            number_of_apartmentsLabel = new System.Windows.Forms.Label();
            passportLabel = new System.Windows.Forms.Label();
            personnel_numberLabel = new System.Windows.Forms.Label();
            phone_numberLabel = new System.Windows.Forms.Label();
            position_codeLabel = new System.Windows.Forms.Label();
            salaryLabel = new System.Windows.Forms.Label();
            secondnameLabel = new System.Windows.Forms.Label();
            standart_deductionLabel = new System.Windows.Forms.Label();
            subdivision_codeLabel = new System.Windows.Forms.Label();
            value_of_DependentsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.positionsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.subdivisionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            addressLabel.Location = new System.Drawing.Point(12, 191);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(41, 13);
            addressLabel.TabIndex = 41;
            addressLabel.Text = "Адрес:";
            // 
            // availability_carLabel
            // 
            availability_carLabel.AutoSize = true;
            availability_carLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            availability_carLabel.Location = new System.Drawing.Point(12, 459);
            availability_carLabel.Name = "availability_carLabel";
            availability_carLabel.Size = new System.Drawing.Size(79, 13);
            availability_carLabel.TabIndex = 43;
            availability_carLabel.Text = "Наличие авто:";
            // 
            // availability_kidsLabel
            // 
            availability_kidsLabel.AutoSize = true;
            availability_kidsLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            availability_kidsLabel.Location = new System.Drawing.Point(12, 489);
            availability_kidsLabel.Name = "availability_kidsLabel";
            availability_kidsLabel.Size = new System.Drawing.Size(85, 13);
            availability_kidsLabel.TabIndex = 45;
            availability_kidsLabel.Text = "Наличие детей:";
            // 
            // bithdayLabel
            // 
            bithdayLabel.AutoSize = true;
            bithdayLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            bithdayLabel.Location = new System.Drawing.Point(12, 114);
            bithdayLabel.Name = "bithdayLabel";
            bithdayLabel.Size = new System.Drawing.Size(89, 13);
            bithdayLabel.TabIndex = 47;
            bithdayLabel.Text = "Дата рождения:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            cityLabel.Location = new System.Drawing.Point(12, 165);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(40, 13);
            cityLabel.TabIndex = 49;
            cityLabel.Text = "Город:";
            // 
            // firstnameLabel
            // 
            firstnameLabel.AutoSize = true;
            firstnameLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            firstnameLabel.Location = new System.Drawing.Point(12, 35);
            firstnameLabel.Name = "firstnameLabel";
            firstnameLabel.Size = new System.Drawing.Size(32, 13);
            firstnameLabel.TabIndex = 51;
            firstnameLabel.Text = "Имя:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            genderLabel.Location = new System.Drawing.Point(12, 375);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(30, 13);
            genderLabel.TabIndex = 53;
            genderLabel.Text = "Пол:";
            // 
            // iNNLabel
            // 
            iNNLabel.AutoSize = true;
            iNNLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            iNNLabel.Location = new System.Drawing.Point(12, 349);
            iNNLabel.Name = "iNNLabel";
            iNNLabel.Size = new System.Drawing.Size(34, 13);
            iNNLabel.TabIndex = 55;
            iNNLabel.Text = "ИНН:";
            // 
            // midnameLabel
            // 
            midnameLabel.AutoSize = true;
            midnameLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            midnameLabel.Location = new System.Drawing.Point(12, 87);
            midnameLabel.Name = "midnameLabel";
            midnameLabel.Size = new System.Drawing.Size(57, 13);
            midnameLabel.TabIndex = 57;
            midnameLabel.Text = "Отчество:";
            // 
            // number_of_apartmentsLabel
            // 
            number_of_apartmentsLabel.AutoSize = true;
            number_of_apartmentsLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            number_of_apartmentsLabel.Location = new System.Drawing.Point(12, 323);
            number_of_apartmentsLabel.Name = "number_of_apartmentsLabel";
            number_of_apartmentsLabel.Size = new System.Drawing.Size(113, 13);
            number_of_apartmentsLabel.TabIndex = 59;
            number_of_apartmentsLabel.Text = "Количество квартир:";
            // 
            // passportLabel
            // 
            passportLabel.AutoSize = true;
            passportLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            passportLabel.Location = new System.Drawing.Point(12, 243);
            passportLabel.Name = "passportLabel";
            passportLabel.Size = new System.Drawing.Size(53, 13);
            passportLabel.TabIndex = 61;
            passportLabel.Text = "Паспорт:";
            // 
            // personnel_numberLabel
            // 
            personnel_numberLabel.AutoSize = true;
            personnel_numberLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            personnel_numberLabel.Location = new System.Drawing.Point(12, 9);
            personnel_numberLabel.Name = "personnel_numberLabel";
            personnel_numberLabel.Size = new System.Drawing.Size(102, 13);
            personnel_numberLabel.TabIndex = 63;
            personnel_numberLabel.Text = "Табельный номер:";
            // 
            // phone_numberLabel
            // 
            phone_numberLabel.AutoSize = true;
            phone_numberLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            phone_numberLabel.Location = new System.Drawing.Point(12, 217);
            phone_numberLabel.Name = "phone_numberLabel";
            phone_numberLabel.Size = new System.Drawing.Size(110, 13);
            phone_numberLabel.TabIndex = 65;
            phone_numberLabel.Text = "Телефонный номер:";
            // 
            // position_codeLabel
            // 
            position_codeLabel.AutoSize = true;
            position_codeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            position_codeLabel.Location = new System.Drawing.Point(12, 296);
            position_codeLabel.Name = "position_codeLabel";
            position_codeLabel.Size = new System.Drawing.Size(68, 13);
            position_codeLabel.TabIndex = 67;
            position_codeLabel.Text = "Должность:";
            // 
            // salaryLabel
            // 
            salaryLabel.AutoSize = true;
            salaryLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            salaryLabel.Location = new System.Drawing.Point(12, 139);
            salaryLabel.Name = "salaryLabel";
            salaryLabel.Size = new System.Drawing.Size(42, 13);
            salaryLabel.TabIndex = 69;
            salaryLabel.Text = "Оклад:";
            // 
            // secondnameLabel
            // 
            secondnameLabel.AutoSize = true;
            secondnameLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            secondnameLabel.Location = new System.Drawing.Point(12, 61);
            secondnameLabel.Name = "secondnameLabel";
            secondnameLabel.Size = new System.Drawing.Size(59, 13);
            secondnameLabel.TabIndex = 71;
            secondnameLabel.Text = "Фамилия:";
            // 
            // standart_deductionLabel
            // 
            standart_deductionLabel.AutoSize = true;
            standart_deductionLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            standart_deductionLabel.Location = new System.Drawing.Point(12, 429);
            standart_deductionLabel.Name = "standart_deductionLabel";
            standart_deductionLabel.Size = new System.Drawing.Size(110, 13);
            standart_deductionLabel.TabIndex = 73;
            standart_deductionLabel.Text = "Стандартный вычет:";
            // 
            // subdivision_codeLabel
            // 
            subdivision_codeLabel.AutoSize = true;
            subdivision_codeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            subdivision_codeLabel.Location = new System.Drawing.Point(12, 269);
            subdivision_codeLabel.Name = "subdivision_codeLabel";
            subdivision_codeLabel.Size = new System.Drawing.Size(90, 13);
            subdivision_codeLabel.TabIndex = 75;
            subdivision_codeLabel.Text = "Подразделение:";
            // 
            // value_of_DependentsLabel
            // 
            value_of_DependentsLabel.AutoSize = true;
            value_of_DependentsLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            value_of_DependentsLabel.Location = new System.Drawing.Point(12, 401);
            value_of_DependentsLabel.Name = "value_of_DependentsLabel";
            value_of_DependentsLabel.Size = new System.Drawing.Size(134, 13);
            value_of_DependentsLabel.TabIndex = 77;
            value_of_DependentsLabel.Text = "Количество иждевенцев:";
            // 
            // button_save
            // 
            this.button_save.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_save.Location = new System.Drawing.Point(15, 519);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(125, 30);
            this.button_save.TabIndex = 39;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_exit
            // 
            this.button_exit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button_exit.Location = new System.Drawing.Point(222, 519);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 40;
            this.button_exit.Text = "Назад";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataSource = typeof(HR_Department.Employees);
            // 
            // availability_carCheckBox
            // 
            this.availability_carCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Availability_car", true));
            this.availability_carCheckBox.Location = new System.Drawing.Point(258, 454);
            this.availability_carCheckBox.Name = "availability_carCheckBox";
            this.availability_carCheckBox.Size = new System.Drawing.Size(15, 24);
            this.availability_carCheckBox.TabIndex = 44;
            this.availability_carCheckBox.UseVisualStyleBackColor = true;
            // 
            // availability_kidsCheckBox
            // 
            this.availability_kidsCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Availability_kids", true));
            this.availability_kidsCheckBox.Location = new System.Drawing.Point(258, 484);
            this.availability_kidsCheckBox.Name = "availability_kidsCheckBox";
            this.availability_kidsCheckBox.Size = new System.Drawing.Size(15, 24);
            this.availability_kidsCheckBox.TabIndex = 46;
            this.availability_kidsCheckBox.UseVisualStyleBackColor = true;
            // 
            // bithdayDateTimePicker
            // 
            this.bithdayDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.employeesBindingSource, "Bithday", true));
            this.bithdayDateTimePicker.Location = new System.Drawing.Point(152, 110);
            this.bithdayDateTimePicker.Name = "bithdayDateTimePicker";
            this.bithdayDateTimePicker.Size = new System.Drawing.Size(215, 20);
            this.bithdayDateTimePicker.TabIndex = 48;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(152, 162);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(215, 20);
            this.cityTextBox.TabIndex = 50;
            // 
            // firstnameTextBox
            // 
            this.firstnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Firstname", true));
            this.firstnameTextBox.Location = new System.Drawing.Point(152, 32);
            this.firstnameTextBox.Name = "firstnameTextBox";
            this.firstnameTextBox.Size = new System.Drawing.Size(215, 20);
            this.firstnameTextBox.TabIndex = 52;
            // 
            // genderTextBox
            // 
            this.genderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Gender", true));
            this.genderTextBox.Location = new System.Drawing.Point(152, 372);
            this.genderTextBox.Name = "genderTextBox";
            this.genderTextBox.Size = new System.Drawing.Size(215, 20);
            this.genderTextBox.TabIndex = 54;
            // 
            // midnameTextBox
            // 
            this.midnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Midname", true));
            this.midnameTextBox.Location = new System.Drawing.Point(152, 84);
            this.midnameTextBox.Name = "midnameTextBox";
            this.midnameTextBox.Size = new System.Drawing.Size(215, 20);
            this.midnameTextBox.TabIndex = 58;
            // 
            // number_of_apartmentsTextBox
            // 
            this.number_of_apartmentsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Number_of_apartments", true));
            this.number_of_apartmentsTextBox.Location = new System.Drawing.Point(152, 320);
            this.number_of_apartmentsTextBox.Name = "number_of_apartmentsTextBox";
            this.number_of_apartmentsTextBox.Size = new System.Drawing.Size(215, 20);
            this.number_of_apartmentsTextBox.TabIndex = 60;
            // 
            // personnel_numberTextBox
            // 
            this.personnel_numberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Personnel_number", true));
            this.personnel_numberTextBox.Location = new System.Drawing.Point(152, 6);
            this.personnel_numberTextBox.Name = "personnel_numberTextBox";
            this.personnel_numberTextBox.Size = new System.Drawing.Size(215, 20);
            this.personnel_numberTextBox.TabIndex = 64;
            // 
            // position_codeComboBox
            // 
            this.position_codeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Position_code", true));
            this.position_codeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.employeesBindingSource, "Position_code", true));
            this.position_codeComboBox.DataSource = this.positionsBindingSource;
            this.position_codeComboBox.DisplayMember = "Position_name";
            this.position_codeComboBox.FormattingEnabled = true;
            this.position_codeComboBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.position_codeComboBox.Location = new System.Drawing.Point(152, 293);
            this.position_codeComboBox.Name = "position_codeComboBox";
            this.position_codeComboBox.Size = new System.Drawing.Size(215, 21);
            this.position_codeComboBox.TabIndex = 68;
            this.position_codeComboBox.ValueMember = "Position_code";
            // 
            // positionsBindingSource
            // 
            this.positionsBindingSource.DataSource = typeof(HR_Department.Positions);
            // 
            // salaryTextBox
            // 
            this.salaryTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Salary", true));
            this.salaryTextBox.Location = new System.Drawing.Point(152, 136);
            this.salaryTextBox.Name = "salaryTextBox";
            this.salaryTextBox.Size = new System.Drawing.Size(215, 20);
            this.salaryTextBox.TabIndex = 70;
            // 
            // secondnameTextBox
            // 
            this.secondnameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Secondname", true));
            this.secondnameTextBox.Location = new System.Drawing.Point(152, 58);
            this.secondnameTextBox.Name = "secondnameTextBox";
            this.secondnameTextBox.Size = new System.Drawing.Size(215, 20);
            this.secondnameTextBox.TabIndex = 72;
            // 
            // standart_deductionCheckBox
            // 
            this.standart_deductionCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Standart_deduction", true));
            this.standart_deductionCheckBox.Location = new System.Drawing.Point(258, 424);
            this.standart_deductionCheckBox.Name = "standart_deductionCheckBox";
            this.standart_deductionCheckBox.Size = new System.Drawing.Size(15, 24);
            this.standart_deductionCheckBox.TabIndex = 74;
            this.standart_deductionCheckBox.UseVisualStyleBackColor = true;
            // 
            // subdivision_codeComboBox
            // 
            this.subdivision_codeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Subdivision_code", true));
            this.subdivision_codeComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.employeesBindingSource, "Subdivisions", true));
            this.subdivision_codeComboBox.DataSource = this.subdivisionsBindingSource;
            this.subdivision_codeComboBox.DisplayMember = "Subdivision_name";
            this.subdivision_codeComboBox.FormattingEnabled = true;
            this.subdivision_codeComboBox.Location = new System.Drawing.Point(152, 266);
            this.subdivision_codeComboBox.Name = "subdivision_codeComboBox";
            this.subdivision_codeComboBox.Size = new System.Drawing.Size(215, 21);
            this.subdivision_codeComboBox.TabIndex = 76;
            this.subdivision_codeComboBox.ValueMember = "Subdivision_code";
            // 
            // subdivisionsBindingSource
            // 
            this.subdivisionsBindingSource.DataSource = typeof(HR_Department.Subdivisions);
            // 
            // value_of_DependentsTextBox
            // 
            this.value_of_DependentsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Value_of_Dependents", true));
            this.value_of_DependentsTextBox.Location = new System.Drawing.Point(152, 398);
            this.value_of_DependentsTextBox.Name = "value_of_DependentsTextBox";
            this.value_of_DependentsTextBox.Size = new System.Drawing.Size(215, 20);
            this.value_of_DependentsTextBox.TabIndex = 78;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "City", true));
            this.addressTextBox.Location = new System.Drawing.Point(152, 188);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(215, 20);
            this.addressTextBox.TabIndex = 79;
            // 
            // passportTextBox
            // 
            this.passportTextBox.Location = new System.Drawing.Point(152, 240);
            this.passportTextBox.Mask = "0000 000000";
            this.passportTextBox.Name = "passportTextBox";
            this.passportTextBox.Size = new System.Drawing.Size(215, 20);
            this.passportTextBox.TabIndex = 80;
            // 
            // iNNTextBox
            // 
            this.iNNTextBox.Location = new System.Drawing.Point(152, 346);
            this.iNNTextBox.Mask = "000000000000";
            this.iNNTextBox.Name = "iNNTextBox";
            this.iNNTextBox.Size = new System.Drawing.Size(215, 20);
            this.iNNTextBox.TabIndex = 81;
            // 
            // phone_numberTextBox
            // 
            this.phone_numberTextBox.Location = new System.Drawing.Point(152, 215);
            this.phone_numberTextBox.Mask = "8(000)000-00-00";
            this.phone_numberTextBox.Name = "phone_numberTextBox";
            this.phone_numberTextBox.Size = new System.Drawing.Size(215, 20);
            this.phone_numberTextBox.TabIndex = 82;
            // 
            // Form_Empl_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(374, 561);
            this.Controls.Add(this.phone_numberTextBox);
            this.Controls.Add(this.iNNTextBox);
            this.Controls.Add(this.passportTextBox);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(availability_carLabel);
            this.Controls.Add(this.availability_carCheckBox);
            this.Controls.Add(availability_kidsLabel);
            this.Controls.Add(this.availability_kidsCheckBox);
            this.Controls.Add(bithdayLabel);
            this.Controls.Add(this.bithdayDateTimePicker);
            this.Controls.Add(cityLabel);
            this.Controls.Add(this.cityTextBox);
            this.Controls.Add(firstnameLabel);
            this.Controls.Add(this.firstnameTextBox);
            this.Controls.Add(genderLabel);
            this.Controls.Add(this.genderTextBox);
            this.Controls.Add(iNNLabel);
            this.Controls.Add(midnameLabel);
            this.Controls.Add(this.midnameTextBox);
            this.Controls.Add(number_of_apartmentsLabel);
            this.Controls.Add(this.number_of_apartmentsTextBox);
            this.Controls.Add(passportLabel);
            this.Controls.Add(personnel_numberLabel);
            this.Controls.Add(this.personnel_numberTextBox);
            this.Controls.Add(phone_numberLabel);
            this.Controls.Add(position_codeLabel);
            this.Controls.Add(this.position_codeComboBox);
            this.Controls.Add(salaryLabel);
            this.Controls.Add(this.salaryTextBox);
            this.Controls.Add(secondnameLabel);
            this.Controls.Add(this.secondnameTextBox);
            this.Controls.Add(standart_deductionLabel);
            this.Controls.Add(this.standart_deductionCheckBox);
            this.Controls.Add(subdivision_codeLabel);
            this.Controls.Add(this.subdivision_codeComboBox);
            this.Controls.Add(value_of_DependentsLabel);
            this.Controls.Add(this.value_of_DependentsTextBox);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_save);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MaximumSize = new System.Drawing.Size(390, 600);
            this.MinimumSize = new System.Drawing.Size(390, 600);
            this.Name = "Form_Empl_add";
            this.Text = "Добавить сотрудника";
            this.Load += new System.EventHandler(this.Form_Empl_add_Load);
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.positionsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.subdivisionsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private System.Windows.Forms.CheckBox availability_carCheckBox;
        private System.Windows.Forms.CheckBox availability_kidsCheckBox;
        private System.Windows.Forms.DateTimePicker bithdayDateTimePicker;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox firstnameTextBox;
        private System.Windows.Forms.TextBox genderTextBox;
        private System.Windows.Forms.TextBox midnameTextBox;
        private System.Windows.Forms.TextBox number_of_apartmentsTextBox;
        private System.Windows.Forms.TextBox personnel_numberTextBox;
        private System.Windows.Forms.ComboBox position_codeComboBox;
        private System.Windows.Forms.TextBox salaryTextBox;
        private System.Windows.Forms.TextBox secondnameTextBox;
        private System.Windows.Forms.CheckBox standart_deductionCheckBox;
        private System.Windows.Forms.ComboBox subdivision_codeComboBox;
        private System.Windows.Forms.TextBox value_of_DependentsTextBox;
        private System.Windows.Forms.BindingSource positionsBindingSource;
        private System.Windows.Forms.BindingSource subdivisionsBindingSource;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.MaskedTextBox passportTextBox;
        private System.Windows.Forms.MaskedTextBox iNNTextBox;
        private System.Windows.Forms.MaskedTextBox phone_numberTextBox;
    }
}