﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Order_change : Form
    {

        public Model_HR database { get; set; }
        public Orders order { get; set; }

        public Form_Order_change()
        {
            InitializeComponent();
        }

        private void Form_Order_change_Load(object sender, EventArgs e)
        {
            employeesBindingSource.DataSource = database.Employees.ToList();

            order_codeTextBox.Text = order.Order_code.ToString();
            customerTextBox.Text = order.Customer.ToString();
            order_dateDateTimePicker.Value = order.Order_date.Value;
            cost_RubTextBox.Text = order.Cost_Rub.ToString();
            work_typeTextBox.Text = order.Work_type.ToString();
            personnel_numberComboBox.Text = order.Personnel_number.ToString();

        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            order.Cost_Rub = Convert.ToDecimal(cost_RubTextBox.Text);
            order.Customer = customerTextBox.Text;
            order.Order_date = order_dateDateTimePicker.Value;
            order.Personnel_number = int.Parse(personnel_numberComboBox.SelectedValue.ToString());

            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }
    }
}
