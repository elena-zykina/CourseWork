﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Empl_change : Form
    {

        public Model_HR database { get; set; }
        public Employees employee { get; set; }

        public Form_Empl_change()
        {
            InitializeComponent();
        }

        private void Form_Empl_change_Load(object sender, EventArgs e)
        {

            positionsBindingSource.DataSource = database.Positions.ToList();
            subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            subdivision_codeComboBox.Text = employee.Subdivision_code.ToString();
            position_codeComboBox.Text = employee.Position_code.ToString();

            salaryTextBox.Text = employee.Salary.ToString();
            

            addressTextBox.Text = employee.Address.ToString();
            availability_carCheckBox.Checked = employee.Availability_car.Value;
            availability_kidsCheckBox.Checked = employee.Availability_kids.Value;
            bithdayDateTimePicker.Value = employee.Bithday.Value;
            cityTextBox.Text = employee.City.ToString();
            firstnameTextBox.Text = employee.Firstname.ToString();
            secondnameTextBox.Text = employee.Secondname.ToString();
            midnameTextBox.Text = employee.Midname.ToString();
            genderTextBox.Text = employee.Gender.ToString();
            iNNTextBox.Text = employee.INN.ToString();
            number_of_apartmentsTextBox.Text = employee.Number_of_apartments.ToString();
            passportTextBox.Text = employee.Passport.ToString();
            personnel_numberTextBox.Text = employee.Personnel_number.ToString();
            phone_numberTextBox.Text = employee.Phone_number.ToString();
            standart_deductionCheckBox.Checked = employee.Standart_deduction.Value;
            value_of_DependentsTextBox.Text = employee.Value_of_Dependents.ToString();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            int Number_of_apartments, personnel_number = 0, Value_of_Dependents = 0;
            bool values_not_null = int.TryParse(number_of_apartmentsTextBox.Text, out Number_of_apartments) &&
                int.TryParse(personnel_numberTextBox.Text, out personnel_number) &&
                int.TryParse(value_of_DependentsTextBox.Text, out Value_of_Dependents) &&
                int.TryParse(number_of_apartmentsTextBox.Text, out Number_of_apartments);

            if (!values_not_null)
            {
                MessageBox.Show("Проверьте корректность введённых данных");
                return;
            }

            employee.Address = addressTextBox.Text;
            employee.Availability_car = availability_carCheckBox.Checked;
            employee.Availability_kids = availability_kidsCheckBox.Checked;
            employee.Bithday = bithdayDateTimePicker.Value;
            employee.City = cityTextBox.Text;
            employee.Firstname = firstnameTextBox.Text;
            employee.Secondname = secondnameTextBox.Text;
            employee.Standart_deduction = standart_deductionCheckBox.Checked;
            employee.Gender = genderTextBox.Text;
            employee.Midname = midnameTextBox.Text;
            employee.Passport = passportTextBox.Text;
            employee.INN = iNNTextBox.Text;
            employee.Number_of_apartments = Number_of_apartments;
            employee.Personnel_number = personnel_number;
            employee.Phone_number = phone_numberTextBox.Text;
            employee.Salary = Convert.ToDecimal(salaryTextBox.Text);
            employee.Value_of_Dependents = Value_of_Dependents;

            employee.Subdivision_code = int.Parse(subdivision_codeComboBox.SelectedValue.ToString());
            employee.Position_code = int.Parse(position_codeComboBox.SelectedValue.ToString());

            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }
    }
}
