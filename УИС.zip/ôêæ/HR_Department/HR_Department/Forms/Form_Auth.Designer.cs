﻿
namespace HR_Department.Forms
{
    partial class Form_Auth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_user = new System.Windows.Forms.ComboBox();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_join = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Пользователь:";
            // 
            // comboBox_user
            // 
            this.comboBox_user.FormattingEnabled = true;
            this.comboBox_user.Items.AddRange(new object[] {
            "Директор",
            "HR менеджер",
            "Менеджер по персоналу"});
            this.comboBox_user.Location = new System.Drawing.Point(100, 5);
            this.comboBox_user.Name = "comboBox_user";
            this.comboBox_user.Size = new System.Drawing.Size(222, 21);
            this.comboBox_user.TabIndex = 1;
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(197, 32);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 2;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_join
            // 
            this.button_join.Location = new System.Drawing.Point(12, 32);
            this.button_join.Name = "button_join";
            this.button_join.Size = new System.Drawing.Size(125, 30);
            this.button_join.TabIndex = 3;
            this.button_join.Text = "Войти";
            this.button_join.UseVisualStyleBackColor = true;
            this.button_join.Click += new System.EventHandler(this.button_join_Click);
            // 
            // Form_Auth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 66);
            this.Controls.Add(this.button_join);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.comboBox_user);
            this.Controls.Add(this.label1);
            this.MaximumSize = new System.Drawing.Size(350, 105);
            this.MinimumSize = new System.Drawing.Size(350, 105);
            this.Name = "Form_Auth";
            this.Text = "Выберите пользователя";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_user;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_join;
    }
}