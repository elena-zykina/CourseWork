﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Empl_add : Form
    {

        public Model_HR database { get; set; }

        public Form_Empl_add()
        {
            InitializeComponent();
            genderTextBox.MaxLength = 1;
            iNNTextBox.MaxLength = 12;
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if(addressTextBox.Text == ""      || bithdayDateTimePicker.Text == ""       || 
               cityTextBox.Text == ""         || firstnameTextBox.Text == ""            ||
               genderTextBox.Text == ""       || iNNTextBox.Text == ""                  ||
               midnameTextBox.Text == ""      || number_of_apartmentsTextBox.Text == "" ||
               passportTextBox.Text == ""     || personnel_numberTextBox.Text == ""     ||
               phone_numberTextBox.Text == "" || salaryTextBox.Text == ""               ||
               secondnameTextBox.Text == ""   || value_of_DependentsTextBox.Text == "")
            {
                MessageBox.Show("Необходимо ввести все требуемые данные!");
                return;
            }

            int Number_of_apartments, personnel_number = 0, Value_of_Dependents = 0;
            bool values_not_null = int.TryParse(number_of_apartmentsTextBox.Text, out Number_of_apartments) &&
                int.TryParse(personnel_numberTextBox.Text, out personnel_number) &&
                int.TryParse(value_of_DependentsTextBox.Text, out Value_of_Dependents) &&
                int.TryParse(number_of_apartmentsTextBox.Text, out Number_of_apartments);

            if (!values_not_null)
            {
                MessageBox.Show("Проверьте корректность введённых данных");
                return;
            }

            Employees employe = new Employees();

            employe.Address = addressTextBox.Text;
            employe.Availability_car = availability_carCheckBox.Checked;
            employe.Availability_kids = availability_kidsCheckBox.Checked;
            employe.Bithday = bithdayDateTimePicker.Value;
            employe.City = cityTextBox.Text;
            employe.Firstname = firstnameTextBox.Text;
            employe.Secondname = secondnameTextBox.Text;
            employe.Standart_deduction = standart_deductionCheckBox.Checked;
            employe.Gender = genderTextBox.Text;
            employe.Midname = midnameTextBox.Text;
            employe.Passport = passportTextBox.Text;
            employe.INN = iNNTextBox.Text;
            employe.Number_of_apartments = Number_of_apartments;
            employe.Personnel_number = personnel_number;
            employe.Phone_number = phone_numberTextBox.Text;
            employe.Salary = Convert.ToDecimal(salaryTextBox.Text);
            employe.Value_of_Dependents = Value_of_Dependents;

            employe.Subdivision_code = int.Parse(subdivision_codeComboBox.SelectedValue.ToString());
            employe.Position_code = int.Parse(position_codeComboBox.SelectedValue.ToString());

            database.Employees.Add(employe);
            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form_Empl_add_Load(object sender, EventArgs e)
        {
            positionsBindingSource.DataSource = database.Positions.ToList();
            subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
        }
    }
}
