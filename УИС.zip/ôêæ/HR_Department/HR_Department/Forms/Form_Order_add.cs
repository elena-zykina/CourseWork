﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Order_add : Form
    {

        public Model_HR database { get; set; }

        public Form_Order_add()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if(cost_RubTextBox.Text == "" || customerTextBox.Text == "" ||
                order_codeTextBox.Text == "" || order_dateDateTimePicker.Text == "" ||
                personnel_numberComboBox.Text == "" || work_typeTextBox.Text == "")
            {
                MessageBox.Show("Необходимо ввести все требуемые данные!");
                return;
            }

            int order_code;
            bool order_code_changed = int.TryParse(order_codeTextBox.Text, out order_code);
            if (!order_code_changed)
            {
                MessageBox.Show("Неверный формат кода!");
                return;
            }

            Orders order = new Orders();

            order.Cost_Rub = Convert.ToDecimal(cost_RubTextBox.Text);
            order.Customer = customerTextBox.Text;
            order.Order_code = order_code;
            order.Order_date = order_dateDateTimePicker.Value;
            order.Personnel_number = int.Parse(personnel_numberComboBox.SelectedValue.ToString());
            order.Work_type = work_typeTextBox.Text;

            database.Orders.Add(order);
            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form_Order_add_Load(object sender, EventArgs e)
        {
            employeesBindingSource.DataSource = database.Employees.ToList();
        }
    }
}
