﻿
namespace HR_Department.Forms
{
    partial class Form_Subdiv_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label subdivision_bonusLabel;
            System.Windows.Forms.Label subdivision_codeLabel;
            System.Windows.Forms.Label subdivision_nameLabel;
            this.textbox_subdiv_bonus = new System.Windows.Forms.TextBox();
            this.subdivisionsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.textbox_subdiv_code = new System.Windows.Forms.TextBox();
            this.textbox_subdiv_name = new System.Windows.Forms.TextBox();
            this.button_save = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            subdivision_bonusLabel = new System.Windows.Forms.Label();
            subdivision_codeLabel = new System.Windows.Forms.Label();
            subdivision_nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.subdivisionsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // subdivision_bonusLabel
            // 
            subdivision_bonusLabel.AutoSize = true;
            subdivision_bonusLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            subdivision_bonusLabel.Location = new System.Drawing.Point(12, 61);
            subdivision_bonusLabel.Name = "subdivision_bonusLabel";
            subdivision_bonusLabel.Size = new System.Drawing.Size(121, 13);
            subdivision_bonusLabel.TabIndex = 1;
            subdivision_bonusLabel.Text = "Бонус подразделения:";
            // 
            // subdivision_codeLabel
            // 
            subdivision_codeLabel.AutoSize = true;
            subdivision_codeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            subdivision_codeLabel.Location = new System.Drawing.Point(12, 9);
            subdivision_codeLabel.Name = "subdivision_codeLabel";
            subdivision_codeLabel.Size = new System.Drawing.Size(110, 13);
            subdivision_codeLabel.TabIndex = 3;
            subdivision_codeLabel.Text = "Код подразделения:";
            // 
            // subdivision_nameLabel
            // 
            subdivision_nameLabel.AutoSize = true;
            subdivision_nameLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            subdivision_nameLabel.Location = new System.Drawing.Point(12, 35);
            subdivision_nameLabel.Name = "subdivision_nameLabel";
            subdivision_nameLabel.Size = new System.Drawing.Size(113, 13);
            subdivision_nameLabel.TabIndex = 5;
            subdivision_nameLabel.Text = "Имя подразделения:";
            // 
            // textbox_subdiv_bonus
            // 
            this.textbox_subdiv_bonus.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subdivisionsBindingSource, "Subdivision_bonus", true));
            this.textbox_subdiv_bonus.Location = new System.Drawing.Point(144, 58);
            this.textbox_subdiv_bonus.Name = "textbox_subdiv_bonus";
            this.textbox_subdiv_bonus.Size = new System.Drawing.Size(145, 20);
            this.textbox_subdiv_bonus.TabIndex = 2;
            // 
            // subdivisionsBindingSource
            // 
            this.subdivisionsBindingSource.DataSource = typeof(HR_Department.Subdivisions);
            // 
            // textbox_subdiv_code
            // 
            this.textbox_subdiv_code.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subdivisionsBindingSource, "Subdivision_code", true));
            this.textbox_subdiv_code.Location = new System.Drawing.Point(144, 6);
            this.textbox_subdiv_code.Name = "textbox_subdiv_code";
            this.textbox_subdiv_code.Size = new System.Drawing.Size(145, 20);
            this.textbox_subdiv_code.TabIndex = 4;
            // 
            // textbox_subdiv_name
            // 
            this.textbox_subdiv_name.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.subdivisionsBindingSource, "Subdivision_name", true));
            this.textbox_subdiv_name.Location = new System.Drawing.Point(144, 32);
            this.textbox_subdiv_name.Name = "textbox_subdiv_name";
            this.textbox_subdiv_name.Size = new System.Drawing.Size(145, 20);
            this.textbox_subdiv_name.TabIndex = 6;
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(12, 84);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(125, 30);
            this.button_save.TabIndex = 7;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(164, 84);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 8;
            this.button_exit.Text = "Назад";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // Form_Subdiv_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(299, 121);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_save);
            this.Controls.Add(subdivision_bonusLabel);
            this.Controls.Add(this.textbox_subdiv_bonus);
            this.Controls.Add(subdivision_codeLabel);
            this.Controls.Add(this.textbox_subdiv_code);
            this.Controls.Add(subdivision_nameLabel);
            this.Controls.Add(this.textbox_subdiv_name);
            this.MaximumSize = new System.Drawing.Size(315, 160);
            this.MinimumSize = new System.Drawing.Size(315, 160);
            this.Name = "Form_Subdiv_add";
            this.Text = "Добавить подразделение";
            ((System.ComponentModel.ISupportInitialize)(this.subdivisionsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource subdivisionsBindingSource;
        private System.Windows.Forms.TextBox textbox_subdiv_bonus;
        private System.Windows.Forms.TextBox textbox_subdiv_code;
        private System.Windows.Forms.TextBox textbox_subdiv_name;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_exit;
    }
}