﻿
namespace HR_Department.Forms
{
    partial class Form_Order_add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label cost_RubLabel;
            System.Windows.Forms.Label customerLabel;
            System.Windows.Forms.Label order_codeLabel;
            System.Windows.Forms.Label order_dateLabel;
            System.Windows.Forms.Label personnel_numberLabel;
            System.Windows.Forms.Label work_typeLabel;
            this.button_save = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.ordersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cost_RubTextBox = new System.Windows.Forms.TextBox();
            this.customerTextBox = new System.Windows.Forms.TextBox();
            this.order_codeTextBox = new System.Windows.Forms.TextBox();
            this.order_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.personnel_numberComboBox = new System.Windows.Forms.ComboBox();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.work_typeTextBox = new System.Windows.Forms.TextBox();
            cost_RubLabel = new System.Windows.Forms.Label();
            customerLabel = new System.Windows.Forms.Label();
            order_codeLabel = new System.Windows.Forms.Label();
            order_dateLabel = new System.Windows.Forms.Label();
            personnel_numberLabel = new System.Windows.Forms.Label();
            work_typeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // cost_RubLabel
            // 
            cost_RubLabel.AutoSize = true;
            cost_RubLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            cost_RubLabel.Location = new System.Drawing.Point(12, 61);
            cost_RubLabel.Name = "cost_RubLabel";
            cost_RubLabel.Size = new System.Drawing.Size(68, 13);
            cost_RubLabel.TabIndex = 15;
            cost_RubLabel.Text = "Цена в руб.:";
            // 
            // customerLabel
            // 
            customerLabel.AutoSize = true;
            customerLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            customerLabel.Location = new System.Drawing.Point(12, 35);
            customerLabel.Name = "customerLabel";
            customerLabel.Size = new System.Drawing.Size(58, 13);
            customerLabel.TabIndex = 17;
            customerLabel.Text = "Заказчик:";
            // 
            // order_codeLabel
            // 
            order_codeLabel.AutoSize = true;
            order_codeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            order_codeLabel.Location = new System.Drawing.Point(12, 9);
            order_codeLabel.Name = "order_codeLabel";
            order_codeLabel.Size = new System.Drawing.Size(68, 13);
            order_codeLabel.TabIndex = 19;
            order_codeLabel.Text = "Код заказа:";
            // 
            // order_dateLabel
            // 
            order_dateLabel.AutoSize = true;
            order_dateLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            order_dateLabel.Location = new System.Drawing.Point(12, 88);
            order_dateLabel.Name = "order_dateLabel";
            order_dateLabel.Size = new System.Drawing.Size(75, 13);
            order_dateLabel.TabIndex = 21;
            order_dateLabel.Text = "Дата заказа:";
            // 
            // personnel_numberLabel
            // 
            personnel_numberLabel.AutoSize = true;
            personnel_numberLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            personnel_numberLabel.Location = new System.Drawing.Point(12, 113);
            personnel_numberLabel.Name = "personnel_numberLabel";
            personnel_numberLabel.Size = new System.Drawing.Size(102, 13);
            personnel_numberLabel.TabIndex = 23;
            personnel_numberLabel.Text = "Табельный номер:";
            // 
            // work_typeLabel
            // 
            work_typeLabel.AutoSize = true;
            work_typeLabel.ForeColor = System.Drawing.SystemColors.ButtonFace;
            work_typeLabel.Location = new System.Drawing.Point(12, 140);
            work_typeLabel.Name = "work_typeLabel";
            work_typeLabel.Size = new System.Drawing.Size(61, 13);
            work_typeLabel.TabIndex = 25;
            work_typeLabel.Text = "Вид работ:";
            // 
            // button_save
            // 
            this.button_save.Location = new System.Drawing.Point(12, 163);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(125, 30);
            this.button_save.TabIndex = 13;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(197, 163);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 14;
            this.button_exit.Text = "Назад";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // ordersBindingSource
            // 
            this.ordersBindingSource.DataSource = typeof(HR_Department.Orders);
            // 
            // cost_RubTextBox
            // 
            this.cost_RubTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Cost_Rub", true));
            this.cost_RubTextBox.Location = new System.Drawing.Point(122, 58);
            this.cost_RubTextBox.Name = "cost_RubTextBox";
            this.cost_RubTextBox.Size = new System.Drawing.Size(200, 20);
            this.cost_RubTextBox.TabIndex = 16;
            // 
            // customerTextBox
            // 
            this.customerTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Customer", true));
            this.customerTextBox.Location = new System.Drawing.Point(122, 32);
            this.customerTextBox.Name = "customerTextBox";
            this.customerTextBox.Size = new System.Drawing.Size(200, 20);
            this.customerTextBox.TabIndex = 18;
            // 
            // order_codeTextBox
            // 
            this.order_codeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Order_code", true));
            this.order_codeTextBox.Location = new System.Drawing.Point(122, 6);
            this.order_codeTextBox.Name = "order_codeTextBox";
            this.order_codeTextBox.Size = new System.Drawing.Size(200, 20);
            this.order_codeTextBox.TabIndex = 20;
            // 
            // order_dateDateTimePicker
            // 
            this.order_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.ordersBindingSource, "Order_date", true));
            this.order_dateDateTimePicker.Location = new System.Drawing.Point(122, 84);
            this.order_dateDateTimePicker.Name = "order_dateDateTimePicker";
            this.order_dateDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.order_dateDateTimePicker.TabIndex = 22;
            // 
            // personnel_numberComboBox
            // 
            this.personnel_numberComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Personnel_number", true));
            this.personnel_numberComboBox.DataSource = this.employeesBindingSource;
            this.personnel_numberComboBox.DisplayMember = "Personnel_number";
            this.personnel_numberComboBox.FormattingEnabled = true;
            this.personnel_numberComboBox.Location = new System.Drawing.Point(122, 110);
            this.personnel_numberComboBox.Name = "personnel_numberComboBox";
            this.personnel_numberComboBox.Size = new System.Drawing.Size(200, 21);
            this.personnel_numberComboBox.TabIndex = 24;
            this.personnel_numberComboBox.ValueMember = "Personnel_number";
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataSource = typeof(HR_Department.Employees);
            // 
            // work_typeTextBox
            // 
            this.work_typeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.ordersBindingSource, "Work_type", true));
            this.work_typeTextBox.Location = new System.Drawing.Point(122, 137);
            this.work_typeTextBox.Name = "work_typeTextBox";
            this.work_typeTextBox.Size = new System.Drawing.Size(200, 20);
            this.work_typeTextBox.TabIndex = 26;
            // 
            // Form_Order_add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(334, 201);
            this.Controls.Add(cost_RubLabel);
            this.Controls.Add(this.cost_RubTextBox);
            this.Controls.Add(customerLabel);
            this.Controls.Add(this.customerTextBox);
            this.Controls.Add(order_codeLabel);
            this.Controls.Add(this.order_codeTextBox);
            this.Controls.Add(order_dateLabel);
            this.Controls.Add(this.order_dateDateTimePicker);
            this.Controls.Add(personnel_numberLabel);
            this.Controls.Add(this.personnel_numberComboBox);
            this.Controls.Add(work_typeLabel);
            this.Controls.Add(this.work_typeTextBox);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_save);
            this.MaximumSize = new System.Drawing.Size(350, 240);
            this.MinimumSize = new System.Drawing.Size(350, 240);
            this.Name = "Form_Order_add";
            this.Text = "Добавить заказ";
            this.Load += new System.EventHandler(this.Form_Order_add_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ordersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.BindingSource ordersBindingSource;
        private System.Windows.Forms.TextBox cost_RubTextBox;
        private System.Windows.Forms.TextBox customerTextBox;
        private System.Windows.Forms.TextBox order_codeTextBox;
        private System.Windows.Forms.DateTimePicker order_dateDateTimePicker;
        private System.Windows.Forms.ComboBox personnel_numberComboBox;
        private System.Windows.Forms.TextBox work_typeTextBox;
        private System.Windows.Forms.BindingSource employeesBindingSource;
    }
}