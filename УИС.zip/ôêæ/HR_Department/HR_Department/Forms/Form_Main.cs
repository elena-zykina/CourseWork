﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HR_Department.Forms;

namespace HR_Department
{
    public partial class Form_Main : Form
    {

        public string user_state;

        public Form_Main()
        {
            InitializeComponent();
        }

        private void button_subdivisions_Click(object sender, EventArgs e)
        {
            Form_Subdivisions subdivisions = new Form_Subdivisions();
            subdivisions.user_state = user_state;
            DialogResult dialogResult = subdivisions.ShowDialog();
        }

        private void button_positions_Click(object sender, EventArgs e)
        {
            Form_Positions positions = new Form_Positions();
            positions.user_state = user_state;
            DialogResult dialogResult = positions.ShowDialog();
        }

        private void button_scheme_Click(object sender, EventArgs e)
        {
            Form_Database_scheme database_scheme = new Form_Database_scheme();
            database_scheme.ShowDialog();
        }

        private void button_employees_Click(object sender, EventArgs e)
        {
            Form_Employees employees = new Form_Employees();
            employees.user_state = user_state;
            DialogResult dialogResult = employees.ShowDialog();
        }

        private void button_orders_Click(object sender, EventArgs e)
        {
            Form_Orders orders = new Form_Orders();
            orders.user_state = user_state;
            DialogResult dialogResult = orders.ShowDialog();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form_Main_Load(object sender, EventArgs e)
        {
            Form_Auth auth = new Form_Auth();
            DialogResult dialogResult = auth.ShowDialog();

            if(dialogResult == DialogResult.Cancel)
            {
                Application.Exit();
            }
            else
            {
                user_state = auth.user_state;
                return;
            }
        }
    }
}
