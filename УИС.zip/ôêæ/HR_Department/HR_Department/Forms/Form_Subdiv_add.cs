﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Subdiv_add : Form
    {

        public Model_HR database { get; set; }

        public Form_Subdiv_add()
        {
            InitializeComponent();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if(textbox_subdiv_code.Text == "" || textbox_subdiv_name.Text == "" || textbox_subdiv_bonus.Text == "")
            {
                MessageBox.Show("Необходимо ввести все требуемые данные!");
                return;
            }

            int code, bonus;
            bool code_changed = int.TryParse(textbox_subdiv_code.Text, out code);
            bool bonus_changed = int.TryParse(textbox_subdiv_bonus.Text, out bonus);

            if (!bonus_changed)
            {
                MessageBox.Show("Неверный формат бонуса: " + textbox_subdiv_bonus.Text);
                return;
            }
            if (!code_changed)
            {
                MessageBox.Show("Неверный формат кода: " + textbox_subdiv_code.Text);
                return;
            }

            Subdivisions subdivision = new Subdivisions();

            subdivision.Subdivision_code = code;
            subdivision.Subdivision_name = textbox_subdiv_name.Text;
            subdivision.Subdivision_bonus = bonus;
            database.Subdivisions.Add(subdivision);
            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
