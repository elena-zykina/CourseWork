﻿
namespace HR_Department
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_subdivisions = new System.Windows.Forms.Button();
            this.button_positions = new System.Windows.Forms.Button();
            this.button_scheme = new System.Windows.Forms.Button();
            this.button_employees = new System.Windows.Forms.Button();
            this.button_orders = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // button_subdivisions
            // 
            this.button_subdivisions.Location = new System.Drawing.Point(12, 238);
            this.button_subdivisions.Name = "button_subdivisions";
            this.button_subdivisions.Size = new System.Drawing.Size(125, 30);
            this.button_subdivisions.TabIndex = 0;
            this.button_subdivisions.Text = "Подразделения";
            this.button_subdivisions.UseVisualStyleBackColor = true;
            this.button_subdivisions.Click += new System.EventHandler(this.button_subdivisions_Click);
            // 
            // button_positions
            // 
            this.button_positions.Location = new System.Drawing.Point(149, 239);
            this.button_positions.Name = "button_positions";
            this.button_positions.Size = new System.Drawing.Size(125, 30);
            this.button_positions.TabIndex = 1;
            this.button_positions.Text = "Должности";
            this.button_positions.UseVisualStyleBackColor = true;
            this.button_positions.Click += new System.EventHandler(this.button_positions_Click);
            // 
            // button_scheme
            // 
            this.button_scheme.Location = new System.Drawing.Point(149, 274);
            this.button_scheme.Name = "button_scheme";
            this.button_scheme.Size = new System.Drawing.Size(125, 30);
            this.button_scheme.TabIndex = 2;
            this.button_scheme.Text = "Схема базы данных";
            this.button_scheme.UseVisualStyleBackColor = true;
            this.button_scheme.Click += new System.EventHandler(this.button_scheme_Click);
            // 
            // button_employees
            // 
            this.button_employees.Location = new System.Drawing.Point(287, 238);
            this.button_employees.Name = "button_employees";
            this.button_employees.Size = new System.Drawing.Size(125, 30);
            this.button_employees.TabIndex = 3;
            this.button_employees.Text = "Сотрудники";
            this.button_employees.UseVisualStyleBackColor = true;
            this.button_employees.Click += new System.EventHandler(this.button_employees_Click);
            // 
            // button_orders
            // 
            this.button_orders.Location = new System.Drawing.Point(12, 274);
            this.button_orders.Name = "button_orders";
            this.button_orders.Size = new System.Drawing.Size(125, 30);
            this.button_orders.TabIndex = 4;
            this.button_orders.Text = "Заказы";
            this.button_orders.UseVisualStyleBackColor = true;
            this.button_orders.Click += new System.EventHandler(this.button_orders_Click);
            // 
            // button_exit
            // 
            this.button_exit.Location = new System.Drawing.Point(287, 274);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(125, 30);
            this.button_exit.TabIndex = 6;
            this.button_exit.Text = "Выйти";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::HR_Department.Properties.Resources.Logo;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(400, 220);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(424, 316);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button_orders);
            this.Controls.Add(this.button_employees);
            this.Controls.Add(this.button_scheme);
            this.Controls.Add(this.button_positions);
            this.Controls.Add(this.button_subdivisions);
            this.MaximumSize = new System.Drawing.Size(440, 355);
            this.MinimumSize = new System.Drawing.Size(440, 355);
            this.Name = "Form_Main";
            this.Text = "Отдел кадров";
            this.Load += new System.EventHandler(this.Form_Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_subdivisions;
        private System.Windows.Forms.Button button_positions;
        private System.Windows.Forms.Button button_scheme;
        private System.Windows.Forms.Button button_employees;
        private System.Windows.Forms.Button button_orders;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_exit;
    }
}