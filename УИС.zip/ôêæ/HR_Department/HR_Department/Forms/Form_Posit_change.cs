﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Posit_change : Form
    {

        public Model_HR database { get; set; }
        public Positions position { get; set; }

        public Form_Posit_change()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            int percent;
            bool percent_changed = int.TryParse(textbox_position_percent.Text, out percent);

            if (!percent_changed)
            {
                MessageBox.Show("Неверный формат процента!");
            }

            position.Position_name = textbox_position_name.Text;
            position.Premial_percent = percent;

            try
            {
                database.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.InnerException.InnerException.Message);
            }
        }

        private void Form_Posit_change_Load(object sender, EventArgs e)
        {
            textbox_position_code.Text = position.Position_code.ToString();
            textbox_position_name.Text = position.Position_name;
            textbox_position_percent.Text = position.Premial_percent.ToString();
        }
    }
}
