﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Orders : Form
    {

        Model_HR database = new Model_HR();
        public string user_state { get; set; }

        public Form_Orders()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            Orders order = (Orders)ordersBindingSource.Current;

            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите удалить запись " + order.Order_code.ToString(),
            "Удаление сотрудника", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                database.Orders.Remove(order);
                try
                {
                    database.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                ordersBindingSource.DataSource = database.Orders.ToList();
            }
        }

        private void Form_Orders_Load(object sender, EventArgs e)
        {
            ordersBindingSource.DataSource = database.Orders.ToList();
            if(user_state == "HR менеджер"||user_state == "Менеджер по персоналу")
            {
                button_add.Hide();
                button_change.Hide();
                button_delete.Hide();
            }
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Form_Order_add order_add = new Form_Order_add();

            order_add.database = database;

            DialogResult dialogResult = order_add.ShowDialog();
            if(dialogResult == DialogResult.OK)
            {
                ordersBindingSource.DataSource = database.Orders.ToList();
            }
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            Form_Order_change order_change = new Form_Order_change();
            Orders order = (Orders)ordersBindingSource.Current;
            order_change.database = database;
            order_change.order = order;

            DialogResult dialogResult = order_change.ShowDialog();
            if(dialogResult == DialogResult.OK)
            {
                ordersBindingSource.DataSource = database.Orders.ToList();
            }
        }
    }
}
