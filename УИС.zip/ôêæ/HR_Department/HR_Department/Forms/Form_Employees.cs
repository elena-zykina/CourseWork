﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HR_Department.Forms
{
    public partial class Form_Employees : Form
    {

        Model_HR database = new Model_HR();

        public string user_state { get; set; }

        public Form_Employees()
        {
            InitializeComponent();
        }

        private void Form_Employees_Load(object sender, EventArgs e)
        {
            subdivisionsBindingSource.DataSource = database.Subdivisions.ToList();
            positionsBindingSource.DataSource = database.Positions.ToList();
            employeesBindingSource.DataSource = database.Employees.ToList();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            Form_Empl_add emp_add_form = new Form_Empl_add();

            emp_add_form.database = database;

            DialogResult dialogResult = emp_add_form.ShowDialog();
            if(dialogResult == DialogResult.OK)
            {
                employeesBindingSource.DataSource = database.Employees.ToList();
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            Employees employe = (Employees)employeesBindingSource.Current;

            DialogResult dialogResult = MessageBox.Show("Вы действительно хотите удалить запись " + employe.Personnel_number.ToString(),
            "Удаление сотрудника", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if(dialogResult == DialogResult.Yes)
            {
                database.Employees.Remove(employe);
                try
                {
                    database.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                employeesBindingSource.DataSource = database.Employees.ToList();
            }
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            Form_Empl_change employe_change = new Form_Empl_change();
            Employees employee = (Employees)employeesBindingSource.Current;
            employe_change.database = database;
            employe_change.employee = employee;

            DialogResult dialogResult = employe_change.ShowDialog();
            if(dialogResult == DialogResult.OK)
            {
                employeesBindingSource.DataSource = database.Employees.ToList();
            }
        }
    }
}
